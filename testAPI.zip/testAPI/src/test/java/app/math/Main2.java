package app.math;

public class Main2 {
    public static void main(String[] args) {
        AmountCalc amountCalc = new AmountCalc();
        amountCalc.countPrice(166);
        System.out.println(amountCalc.getPrice());
    }

}
